Distributions Supported
-----------------------

What distributions or platforms are supported with Fire?
===========

Fire has been tested with CDH, Hortonworks, MapR, AWS EMR, Apache Spark distributions.
 
Note: Any cluster with Apache Spark 1.6+ will work fine with Fire.


Can I run Fire on my Amazon AWS cluster or Microsoft Azure or Google Cloud?
===========

Yes, all Fire needs for successful deployment is a Apache Spark cluster. Fire is deployed on the edge node of the cluster.

