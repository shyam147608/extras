
Release Notes
==========

.. toctree::
   :maxdepth: 2

   2019-sept.rst
   2019-aug.rst
   2019-july.rst
   2019-june.rst
   2019-may.rst
   2019-feb.rst
   2019-jan.rst
   2018-nov.rst
   3.1.0.rst
   2.1.0.rst
   1.4.0.rst
   1.3.0.rst
   
   
   
   

  
