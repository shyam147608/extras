SaveMongoDB
=========== 

It Saves the incoming Dataframe into MongoDB

Input
--------------
It takes in a DataFrame as input

Output
--------------
Incoming dataFrame is passed along to the next nodes.

Type
--------- 

transform

Class
--------- 

fire.nodes.mongodb.NodeSaveMongoDB

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - mongoURI
        - mongo URI
        - URI of mongodb
      * - mongoDBName
        - mongoDB Name
        - mongoDB  Name
      * - mongoTableName
        - mongo Table Name
        - mongo Table Name




