ReadCassandra
=========== 

This node reads data from Apache Cassandra

Type
--------- 

dataset

Class
--------- 

fire.nodes.cassandra.NodeReadCassandra

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - table
        - Cassandra Table
        - Cassandra Table from which to read the data
      * - keyspace
        - Cassandra Keyspace
        - Cassandra Keyspace
      * - cluster
        - Cassandra Cluster
        - The group of the Cluster Level 




