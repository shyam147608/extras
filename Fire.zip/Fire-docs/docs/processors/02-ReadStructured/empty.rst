EmptyDataset
=========== 

It creates an empty DataFrame

Input
--------------
It does not read any input

Output
--------------
It creates an empty DataFrame

Type
--------- 

dataset

Class
--------- 

fire.nodes.dataset.NodeDatasetEmpty

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description




