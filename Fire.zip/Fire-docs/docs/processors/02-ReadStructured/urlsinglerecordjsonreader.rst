URLSingleRecordJSONReader
=========== 

It reads in single record JSON from the given URL and creates a DataFrame from it

Type
--------- 

dataset

Class
--------- 

fire.nodes.dataset.NodeDatasetURLSingleRecordJsonReader

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - URL
        - URL
        - URL from where to read the JSON string from
      * - outputColNames
        - Column Names
        - Column Names
      * - outputColTypes
        - Column Types
        - Data Types
      * - outputColFormats
        - Column Formats
        - Formats




