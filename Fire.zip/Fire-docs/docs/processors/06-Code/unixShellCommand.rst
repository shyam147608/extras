UnixShellCommands
=========== 

This node execute shell command

Type
--------- 

shellcommand

Class
--------- 

fire.nodes.etl.NodeShellCommand

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - shellCommand
        - shell Command
        - Unix Shell Command




