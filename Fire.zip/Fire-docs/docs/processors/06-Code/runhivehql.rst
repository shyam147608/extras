RunHIVEQL
=========== 

This node runs the given SQL on the incoming DataFrame

Input
--------------
This type of node takes in a DataFrame and transforms it to another DataFrame

Output
--------------
This node runs the given SQL on the incoming DataFrame to generate the output DataFrame

Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeRunHiveQL

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - hql
        - HiveQL - HIVE Query Language
        - HiveQL




