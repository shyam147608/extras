H2OMojoLoad
=========== 



Type
--------- 

ml-modelload

Class
--------- 

fire.nodes.h2o.NodeH2OMojoLoad

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - path
        - Absolute Path
        - Absolute Path for loading the H2O Mojo




