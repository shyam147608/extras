SplitProbabilityColumn
=========== 



Type
--------- 

transform

Class
--------- 

fire.nodes.ml.NodeSplitProbabilityCol

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - probabilityColName
        - Probability Column
        - 
      * - numFields
        - NumFields
        - Number of fields in probability columns to extract




