13-evaluate-predict
===============

.. toctree::
   :maxdepth: 2

   binary-classification-evaluator.rst
   multiclass-classification-evaluator.rst
   predict.rst
   regression-evaluator.rst
