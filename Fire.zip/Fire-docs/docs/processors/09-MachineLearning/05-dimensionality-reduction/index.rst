05-dimensionality-reduction
===============

.. toctree::
   :maxdepth: 2

   pca.rst
   svd.rst
