03-feature-extraction
===============

.. toctree::
   :maxdepth: 2

   countvectorizer.rst
   hashingtf.rst
   word2vec.rst
