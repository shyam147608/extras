ML Model Load
=========== 

Type
--------- 

ml-modelload

Class
--------- 

fire.nodes.ml.NodeModelLoad

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - path
        - Path to load the ML Model from
      * - modelType
        - Model Type
        - Type of ML model to load




