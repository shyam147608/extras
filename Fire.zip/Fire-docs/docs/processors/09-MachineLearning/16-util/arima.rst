ARIMA
=========== 



Type
--------- 

transform

Class
--------- 

fire.nodes.ml.NodeARIMA

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - inputCol
        - Input Series Column
        - Input Series Column Name
      * - p
        - P
        - 
      * - d
        - D
        - 
      * - q
        - Q
        - 
      * - numFuture
        - Future Forecast
        - 




