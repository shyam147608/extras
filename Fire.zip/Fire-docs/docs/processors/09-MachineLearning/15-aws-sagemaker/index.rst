15-aws-sagemaker
===============

.. toctree::
   :maxdepth: 2

   kmeanssagemaker.rst
   linearlearnerbinaryclassifier.rst
   linearlearnerregressor.rst
   pcasagemaker.rst
   savesagemaker.rst
   xgboostsagemakerestimator.rst
