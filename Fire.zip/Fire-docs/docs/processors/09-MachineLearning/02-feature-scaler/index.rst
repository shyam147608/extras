02-feature-scaler
===============

.. toctree::
   :maxdepth: 2

   MinMaxScaler.rst
   standardscaler.rst
