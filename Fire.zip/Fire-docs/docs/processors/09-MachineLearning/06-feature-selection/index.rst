06-feature-selection
===============

.. toctree::
   :maxdepth: 2

   ChiSqSelector.rst
   RFormula.rst
   vectorslicer.rst
