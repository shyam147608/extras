04-feature-transformers
===============

.. toctree::
   :maxdepth: 2

   binarizer.rst
   idf.rst
   indexstring.rst
   ngram.rst
   normalizer.rst
   onehotencoder.rst
   PolynominalExpansion.rst
   QuantileDiscretizer.rst
   sqltransformer.rst
   stopwordsremover.rst
   stringindexer.rst
   tokenizer.rst
   vectorassembler.rst
   vectorfunctions.rst
   vectorindexer.rst
   WordToScoreMapping.rst
