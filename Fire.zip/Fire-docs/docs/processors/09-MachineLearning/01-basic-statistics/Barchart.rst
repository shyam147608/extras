BarChart
=========== 

Distribution of categorical data

Type
--------- 

transform

Class
--------- 

fire.nodes.ml.NodeBarChartCal

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - inputCol
        - ColumnName
        - Name of column




