FlagOutlier
=========== 

Falg the outlier based on the selected column using Box-and-Whisker technique.

Type
--------- 

transform

Class
--------- 

fire.nodes.ml.NodeFlagOutlier

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - inputCol
        - Input Column
        - The Input Column to flag the outlier




