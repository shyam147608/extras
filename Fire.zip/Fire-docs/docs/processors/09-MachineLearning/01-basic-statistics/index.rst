01-basic-statistics
===============

.. toctree::
   :maxdepth: 2

   Barchart.rst
   correlation.rst
   flagoutlier.rst
   Histogram.rst
   summary.rst
