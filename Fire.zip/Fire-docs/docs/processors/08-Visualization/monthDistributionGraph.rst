GraphMonthDistribution
=========== 

This node Finds the distribution of months from Date values

Type
--------- 

transform

Class
--------- 

fire.nodes.graph.NodeGraphMonthDistribution

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - title
        - Title
      * - graphType
        - Chart Type
        - input graph type
      * - yCols
        - Y Columns
        - input to y axis




