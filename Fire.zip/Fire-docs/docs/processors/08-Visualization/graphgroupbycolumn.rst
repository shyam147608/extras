GraphGroupByColumn
=========== 

Type
--------- 

transform

Class
--------- 

fire.nodes.graph.NodeGraphGroupByColumn

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - title
        - Title
      * - xlabel
        - X Label
      * - ylabel
        - Y Label
      * - groupByColumn
        - Group By Column
      * - graphType
        - Chart Type




