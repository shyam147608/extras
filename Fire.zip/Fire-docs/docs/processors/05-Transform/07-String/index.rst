07-String
===============

.. toctree::
   :maxdepth: 2

   stringFunctions.rst
   stringfunctionsmultiple.rst
