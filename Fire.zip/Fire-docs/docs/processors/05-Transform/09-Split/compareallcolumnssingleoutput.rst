CompareAllColumnsSingleOutput
============================

Compares 2 incoming DataFrames. Outputs 1 DataFrame (A-B) or (B-A) or (A intersection B) based on user's input

Type
--------- 

join

Class
--------- 

fire.nodes.etl.NodeCompareAllColumnsSingleOutput

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - compareOption
        - Compare Type
        - Comparision options whether (A-B) or (B-A) or (A intersection B)




