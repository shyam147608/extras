05-Transform
===============

.. toctree::
   :maxdepth: 2

   01-Filter/index.rst
   02-DataCleaning/index.rst
   03-DateTime/index.rst
   04-Group/index.rst
   05-Validation/index.rst
   06-Math/index.rst
   07-String/index.rst
   08-Parse/index.rst
   09-Split/index.rst
   10-Condition/index.rst
   11-AddColumn/index.rst
   12-CastDataType/index.rst
   13-Others/index.rst
   movingwindowfunctions.rst
   wordcount.rst
