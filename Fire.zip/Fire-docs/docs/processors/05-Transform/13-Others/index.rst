13-Others
===============

.. toctree::
   :maxdepth: 2

   cdcusingfulltablemerge.rst
   columnsrename.rst
   count.rst
   fixedlength.rst
   geoip.rst
   geopoint.rst
   multiwindowanalyticsfunctions.rst
   multiwindowrankingfunctions.rst
   recoverhivepartitions.rst
   registerteamptable.rst
   rounddouble.rst
   sample.rst
   sortby.rst
   transpose.rst
   windowanalytics.rst
   windowranking.rst
