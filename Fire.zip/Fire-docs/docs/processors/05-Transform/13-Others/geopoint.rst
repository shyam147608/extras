GeoPoint
=========== 



Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeGeoPoint

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - longitude
        - Longitude
        - 
      * - latitude
        - Latitude
        - 




