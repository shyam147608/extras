03-ReadUnstructured
===============

.. toctree::
   :maxdepth: 2

   binaryfiles.rst
   pdf.rst
   pdfimageocr.rst
   textfiles.rst
   tika.rst
   wholetextfiles.rst
