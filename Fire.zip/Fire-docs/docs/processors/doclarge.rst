Notes
=========== 

Allows capturing Notes on the Workflow

Type
--------- 

doc

Class
--------- 

fire.nodes.doc.NodeDocLarge

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - comment
        - Comment
        - Comments for the Workflow




