StructuredStreamingConsoleSink
=========== 

It output the DataFrame to the console

Input
--------------
It takes in DataFrame as input

Output
--------------
It writes the incoming DataFrame to the console.

Type
--------- 

transform

Class
--------- 

fire.nodes.structuredstreaming.NodeStructuredStreamingConsoleSink

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - outputMode
        - Output Mode
        - Output Mode for saving to Files




