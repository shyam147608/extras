12-StructuredStreaming
===============

.. toctree::
   :maxdepth: 2

   consolestructuredstreaming.rst
   csvstructuredstreaming.rst
   filesinkstructuredstreaming.rst
   kafkastructuredstreaming.rst
   kinesisstructuredstreaming.rst
   socketstructuredstreaming.rst
   structuredstreamingfilesink.rst
   structuredstreaminghivesink2.rst
