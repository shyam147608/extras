04-Save
===============

.. toctree::
   :maxdepth: 2

   insertintotable.rst
   kafkaproducer.rst
   saveashivetable.rst
   saveavro.rst
   savecsv.rst
   savejdbc.rst
   savejson.rst
   saveorc.rst
   saveparquet.rst
   upsertjdbc.rst
