SpecifyParameters
=========== 

Provides additional parameters to the workflow. When running with spark-submit, variables can also be given on the command line with --var name=value.

Type
--------- 

doc

Class
--------- 

fire.nodes.util.NodeSpecifyParameters

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - names
        - Parameter Names
        - Parameter Names
      * - values
        - Parameter Values
        - Parameter Values




