UnpersistDataFrame
=========== 

Unpersists the output DataFrames of the given Nodes

Input
--------------
It takes in a DataFrame as input

Output
--------------
The outputs the incoming DataFrame

Type
--------- 

transform

Class
--------- 

fire.nodes.util.NodeUnpersistDataFrame

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - nodeIdsToUnpersist
        - Node ID to Unpersist
        - Output of node to unpersist




