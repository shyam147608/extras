StickyNote
=========== 

Allows capturing Notes on the Workflow

Type
--------- 

sticky

Class
--------- 

fire.nodes.doc.NodeStickyNote

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - comment
        - Comment
        - Comments for the Workflow




