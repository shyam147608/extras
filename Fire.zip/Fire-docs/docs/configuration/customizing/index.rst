Customizing Fire Installation
-----------------------------

Below are the details of Configuring Fire for various requirements:

.. toctree::
   :maxdepth: 1

   configuring-max-upload-file-size.rst
   increasing-memory-of-fire-server.rst
   

   


