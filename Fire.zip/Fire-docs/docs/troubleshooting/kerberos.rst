Kerberos
========

My cluster is Kerberised. How do I setup Fire for it
-----------------------------------------------------------

The steps to setup Fire on a Kerberised cluster are at:

* :doc:`../installation-upgrading/configuration/configuring-kerberos`



