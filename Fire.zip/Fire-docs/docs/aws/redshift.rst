Fire Integration with Redshift
========================

Fire is fully integrated with Redshift. Fire has a number of Processors specifically for Redshift.

Redshift Processors
-------------

Fire has processors for reading from and writing to Redshift. They include:

* Read Redshift AWS
* Write Redshift AWS




