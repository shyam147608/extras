Analytics
========

.. toctree::
   :maxdepth: 2

   analyze-flights-delays.rst
   distribution-graphs.rst
   farmers-markets-on-geo-maps.rst
   general-payment-data-analysis.rst
   jetrail-data-annalysis.rst
   nyc-taxidata-annalysis.rst
   transaction-data-analytics.rst
   
