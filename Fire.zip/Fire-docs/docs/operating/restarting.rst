Restarting Fire at Regular Intervals
------------------------------------

It is a good idea to restart Fire at regular intervals. This could be 4 hrs, 6 hrs, 8 hrs etc. interval.

Restarting enables Fire to continue to run effectively over months. Restarting Fire does not effect any of the running jobs or users.



