Logs in Fire Insights
=====================

In Fire Insights there are 2 processes which run:

* fire server
* fire engine

Logs for Fire Web Server
------------------------

The logs for Fire Web Server go into fireserver.log. The logging level is determined by the properties file conf/log4j.properties.

Example log4j.properties
++++++++++++++++++++++++


How to change the various logging levels
++++++++++++++++++++++++++++++++++++++++



Logs for Fire Engine
--------------------

The logs for Fire Engine go into fire.log. 

