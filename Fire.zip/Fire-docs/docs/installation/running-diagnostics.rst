Running Diagnosics
==================

Linux
-----

Fire Insights needs jdk 1.8 to be available

- java -version

java version "1.8.0_101"


Mac OS
------

Fire Insights needs jdk 1.8 to be available

- java -version

java version "1.8.0_101"


Windows
-------

Fire Insights needs jdk 1.8 to be available

- java -version

java version "1.8.0_101"


