Decision / JSON Parser / SortBy / Empty Dataset
===============================================

Fire provides the following processors:

* JSON Parser Processor
* Decision Processor
* SortBy Processor
* Empty Dataset Processor

https://www.Fire.io/single-post/2018/09/05/New-Processors---Decision-JSON-Parser-SortBy-

