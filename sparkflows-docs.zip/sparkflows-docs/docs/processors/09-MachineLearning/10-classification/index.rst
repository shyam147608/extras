10-classification
===============

.. toctree::
   :maxdepth: 2

   DecisionTreeClassifier.rst
   GBTClassifier.rst
   logisticregression.rst
   MultiLayerPerceptron.rst
   NaiveBayes.rst
   RandomForestClassifier.rst
