08-clustering
===============

.. toctree::
   :maxdepth: 2

   gmm.rst
   kmeans.rst
   lda.rst
