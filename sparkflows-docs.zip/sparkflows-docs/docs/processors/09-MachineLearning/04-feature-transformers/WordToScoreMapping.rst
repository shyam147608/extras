WordToScoreMapping
=========== 

Map the original word of hashValue to score.

Type
--------- 

ml-transformer

Class
--------- 

fire.nodes.ml.NodeWordToScoreMapping

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - words
        - Words
        - Array of words
      * - features
        - Features
        - Vector with hash value of words
      * - output
        - Output
        - 




