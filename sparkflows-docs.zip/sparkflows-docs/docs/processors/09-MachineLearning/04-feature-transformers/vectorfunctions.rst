VectorFunctions
=========== 

Vector Functions for transforming Vectors

Type
--------- 

ml-transformer

Class
--------- 

fire.nodes.ml.NodeVectorFunctions

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - inputCol
        - Input Column
        - The Input column name
      * - vectorFunction
        - Vector Function
        - Vector Function Name
      * - parameter
        - Parameter
        - Parameter for the Function
      * - outputCol
        - Output Column
        - Output column name




