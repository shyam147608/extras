07-split-dataset
===============

.. toctree::
   :maxdepth: 2

   split.rst
   splitprobabilitycol.rst
   stratified_sampling.rst
