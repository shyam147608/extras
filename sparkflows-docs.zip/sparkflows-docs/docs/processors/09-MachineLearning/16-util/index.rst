16-util
===============

.. toctree::
   :maxdepth: 2

   arima.rst
   arimatest.rst
   crossvalidator.rst
   mlmodelload.rst
   mlmodelsave.rst
   pipeline.rst
   roc.rst
   trainvalidationsplit.rst
