HistoGram
=========== 

Computes a histogram of the data using number of bins evenly spaced between the minimum and maximum of the specific columns.

Type
--------- 

transform

Class
--------- 

fire.nodes.ml.NodeHistoGramCal

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - inputCols
        - ColumnName
        - Name of column
      * - bins
        - Bins
        - Number of bins




