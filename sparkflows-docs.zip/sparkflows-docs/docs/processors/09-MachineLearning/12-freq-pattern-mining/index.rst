12-freq-pattern-mining
===============

.. toctree::
   :maxdepth: 2

   fpgrowth.rst
