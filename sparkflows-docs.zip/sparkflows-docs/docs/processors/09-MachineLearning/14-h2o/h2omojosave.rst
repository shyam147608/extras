H2OMojoSave
=========== 



Type
--------- 

ml-modelsave

Class
--------- 

fire.nodes.h2o.NodeH2OMojoSave

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - path
        - Path
        - Path for saving the H2O Mojo




