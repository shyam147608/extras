ScalaUDF
=========== 

This node runs any given Scala code for UDFs

Input
--------------
.

Type
--------- 

scala

Class
--------- 

fire.nodes.etl.NodeUDFScala

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - code
        - Scala
        - Scala code to be run.




