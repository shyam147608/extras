KafkaProducer
=========== 

Write out the Dataframe to a specified Apache Kafka Topic

Type
--------- 

transform

Class
--------- 

fire.nodes.save.NodeKafkaProducer

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - brokers
        - Kafka Brokers
        - Brokers
      * - topic
        - Topic
        - Kafka Topic to write out the incoming Dataframe to




