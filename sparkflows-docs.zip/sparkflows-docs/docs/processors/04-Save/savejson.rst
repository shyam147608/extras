SaveJSON
=========== 

Saves the DataFrame into the specified location in JSON Format

Type
--------- 

transform

Class
--------- 

fire.nodes.save.NodeSaveJSON

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - path
        - Path
        - Path where to save the JSON files
      * - saveMode
        - Save Mode
        - Whether to Append, Overwrite or Error if the path Exists




