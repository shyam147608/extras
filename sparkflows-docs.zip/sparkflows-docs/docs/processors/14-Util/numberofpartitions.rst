NumberOfPartitions
=========== 

This node will get the number partitions in input dataframe.

Type
--------- 

transform

Class
--------- 

fire.nodes.util.NodeGetNumberOfPartitions

Fields
--------- 





