Repartition
=========== 

This node repartitions incoming dataframe into a specified number of partitions

Input
--------------
It accepts a DataFrame as input from the previous Node

Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeRepartition

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - numPartitions
        - Number of Partitions
        - Number of Partitions




