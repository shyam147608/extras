02-DataCleaning
===============

.. toctree::
   :maxdepth: 2

   datawrangling.rst
   dropduplicaterows.rst
   droprowswithnull.rst
   findAndReplace.rst
   findandreplaceusingregexmultiple.rst
   ImputingWithConstant.rst
   ImputingWithMeanValue.rst
   ImputingWithMedianValue.rst
   ImputingWithModeValue.rst
   removeduplicaterows.rst
   removeUnwantedCharacters.rst
   removeunwantedcharactersmultiple.rst
   textCaseTransformer.rst
