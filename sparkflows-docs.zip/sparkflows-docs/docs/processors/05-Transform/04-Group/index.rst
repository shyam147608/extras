04-Group
===============

.. toctree::
   :maxdepth: 2

   cube.rst
   grouper.rst
   pivot.rst
   rollup.rst
