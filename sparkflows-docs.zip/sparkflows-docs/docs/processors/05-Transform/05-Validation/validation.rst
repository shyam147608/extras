Validation
=========== 

Validation Node

Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeValidation

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - description
        - Description
        - Validations being Performed
      * - inputCols
        - Columns
        - Columns
      * - functions
        - Function
        - Validation Function to apply
      * - values
        - Values
        - Values




