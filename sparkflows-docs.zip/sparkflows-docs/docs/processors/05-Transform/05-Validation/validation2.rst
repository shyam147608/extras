ValidationMultiple
=========== 

Validation Multiple Node

Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeValidationMultiple

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - description
        - Description
        - Validations being Performed
      * - inputCols
        - Columns
        - Columns
      * - functions1
        - Function
        - Validation Function to apply
      * - values1
        - Values
        - Values
      * - conditions1
        - Condition
        - Validation Condition to apply
      * - functions2
        - Function
        - Validation Function to apply
      * - values2
        - Values
        - Values
      * - conditions2
        - Condition
        - Validation Condition to apply
      * - functions3
        - Function
        - Validation Function to apply
      * - values3
        - Values
        - Values




