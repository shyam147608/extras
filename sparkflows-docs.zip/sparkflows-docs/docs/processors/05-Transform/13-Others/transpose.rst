Transpose
=========== 

This node transposes a dataframe without performing aggregation function by given column(transposeby). ALL INPUT COLUMNS TO THIS NODE HAVE TO BE OF THE SAME TYPE

Input
--------------
It accepts a DataFrame as input from the previous Node

Output
--------------
Output dataframe consisting of three columns transposeBy, column_name, column_value

Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeTranspose

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - transposeBy
        - TransposeByColumn Name
        - transposeBy column name




