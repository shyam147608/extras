Sample
=========== 

Samples the incoming DataFrame

Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeSample

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - withReplacement
        - With Replacement
        - With or without Replacement
      * - fraction
        - Fraction
        - Fraction
      * - seed
        - Seed
        - Seed




