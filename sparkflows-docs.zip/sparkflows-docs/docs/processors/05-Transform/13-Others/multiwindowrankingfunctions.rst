MultiWindowRanking
=========== 



Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeMultiWindowRanking

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - partitionByCols
        - PartitionBy
        - partition column names separated by comma(,) 
      * - orderByCols
        - OrderBy
        - order by column names separated by comma(,)
      * - windowFunctions
        - WindowFunction
        - Window Function Name
      * - outPutColumns
        - OutPutColumn
        - Enter output field(column) name




