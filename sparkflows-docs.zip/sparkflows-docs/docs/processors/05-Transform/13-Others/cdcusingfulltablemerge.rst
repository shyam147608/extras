CDCUsingFullTableMerge
=========== 

CDC Using Full Table Merge

Type
--------- 

transform

Class
--------- 

fire.nodes.etl.NodeCDCUsingFullTableMerge

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - baseTable
        - Base Table Name
        - Name of the Base Table
      * - idCols
        - ID Column Names
        - ID Column names
      * - modifiedDateCol
        - Modified Date Column
        - Modified Date Column




