CompareSpecificColumns
=========== 

Compares 2 incoming DataFrames on specific columns. Outputs 3 DataFrames (A-B), (B-A), (A intersection B)

Type
--------- 

join

Class
--------- 

fire.nodes.etl.NodeCompareSpecificColumns

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - columnsToCompare
        - Columns to Compare
        - Columns to be used in the comparison




