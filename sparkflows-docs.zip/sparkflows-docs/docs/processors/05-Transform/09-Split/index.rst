09-Split
===============

.. toctree::
   :maxdepth: 2

   compare.rst
   compareallcolumnssingleoutput.rst
   comparespecificcolumns.rst
   comparespecificcolumnssingleoutput.rst
   splitbyexpression.rst
   splitbymultipleexpressions.rst
