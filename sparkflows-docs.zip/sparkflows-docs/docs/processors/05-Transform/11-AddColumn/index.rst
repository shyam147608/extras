11-AddColumn
===============

.. toctree::
   :maxdepth: 2

   addcolumns.rst
   casewhen.rst
   concatcolumns.rst
   expressions.rst
   generateuid.rst
   generateUUID.rst
   hash.rst
   zipwithindex.rst
