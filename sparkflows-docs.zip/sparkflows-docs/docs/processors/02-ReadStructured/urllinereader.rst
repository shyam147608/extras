URLTextFileReader
=========== 

Reads text file from the given URL and creates a DataFrame from it. Each line in the file is a record in the DataFrame.

Type
--------- 

dataset

Class
--------- 

fire.nodes.dataset.NodeDatasetUrlTextFileReader

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - url
        - URL
        - URL of the file




