02-ReadStructured
===============

.. toctree::
   :maxdepth: 2

   avro.rst
   createdataset.rst
   csv.rst
   db2.rst
   empty.rst
   excel.rst
   jdbc.rst
   json.rst
   libsvm.rst
   parquet.rst
   shapefile.rst
   structured.rst
   urllinereader.rst
   urlsinglerecordjsonreader.rst
   xml.rst
