ApacheLogs
=========== 

Reads in Apache Log files from a given path, parses them and loads them into a DataFrame

Type
--------- 

dataset

Class
--------- 

fire.nodes.logs.NodeApacheFileAccessLog

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - path
        - Path
        - Full path for the directory or file for the Apache File Logs




