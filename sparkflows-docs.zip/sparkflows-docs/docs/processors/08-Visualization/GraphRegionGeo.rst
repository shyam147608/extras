GraphRegionGeo
=========== 

This node displays values on a Map

Type
--------- 

transform

Class
--------- 

fire.nodes.graph.NodeGraphRegionGeo

Fields
--------- 

.. list-table::
      :widths: 10 5 10
      :header-rows: 1

      * - Name
        - Title
        - Description
      * - title
        - Title
      * - col1
        - Column 1
      * - col2
        - Column 2
      * - displayMode
        - Display Mode
      * - resolution
        - Resolution
      * - region
        - Region
        - Region of the world to display




