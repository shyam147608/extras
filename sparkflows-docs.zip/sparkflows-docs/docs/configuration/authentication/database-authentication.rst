Database Authentication
=======================

Fire Insights can authenticate the user against its own database.

User's password are stored encrypted.

This is the default authentication mechanism of Fire Insights. Users created in Fire are stored in the database.

