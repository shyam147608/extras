Acquire Token Using CURL
==================

Tokens can be acquired from Fire Insights using curl. They would then be used in making subsequent curl requests.

This page  work is in progress...


