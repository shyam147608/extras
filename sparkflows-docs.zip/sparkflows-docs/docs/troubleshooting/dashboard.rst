Dashboards
==========


When viewing the Dashboard the cells are showing up empty
---------------------------------------------------------

Dashboards show output of Workflows.

If the corresponding workflow has not executed, the content in the Dashboard would show up as empty.

