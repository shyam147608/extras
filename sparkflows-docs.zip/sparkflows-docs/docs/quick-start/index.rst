
Quickstart Guide
=========

The quickstart gets you started with Fire Insights. 

Let's get started! 

.. toctree::
   :maxdepth: 1

   1-create-application.rst
   2-upload-data-files.rst
   3-create-datasets.rst
   4-create-workflow.rst 
   5-execute-workflow.rst 
   6-build-dashboard.rst


