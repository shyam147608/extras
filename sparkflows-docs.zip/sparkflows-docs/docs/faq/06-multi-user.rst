Multi User Support
------------------

How does the Fire platform handle multi-user support (i.e. Can user 1 see or edit user 2’s data sources, pipelines, etc)
===========

Fire supports various user types and enables users to easily share datasets and workflows with each other to foster collaboration.


