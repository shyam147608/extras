Workflow Export - Import
------------------------

How does one export/import workflows between instances?
===========

Fire allows workflows to be exported and imported. Workflows are represented as JSON files and hence can also be checked into github etc. for versioning.

Fire also maintains the version history of the workflows.



