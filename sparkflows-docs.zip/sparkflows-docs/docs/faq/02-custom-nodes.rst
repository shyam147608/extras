Custom Nodes
-------------

Does Fire Insights allow me to create my own custom nodes?
===========

Yes, new Nodes can be easily to added to Fire Insights. Develop nodes in Java or in Scala and dop the definition JSON for the node on the server. The newly added nodes will become visible in the Fire Insights User Interface.




