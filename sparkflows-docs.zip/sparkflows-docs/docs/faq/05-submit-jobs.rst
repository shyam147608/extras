Submit Apache Spark Jobs
-----------------

When running on a Apache Spark cluster how does Fire submit the spark jobs?
=============
 
Fire Insights uses spark-submit to submit the Apache Spark jobs to the cluster. Hence it is important that spark-submit work from the machine on which Fire Insights is installed.
